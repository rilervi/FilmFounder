// import styled from 'styled-components';

// export const BackDrop = styled.section`
//   background-size: cover;
//   background-position: center;
//   background-repeat: no-repeat;
//   height: 92vh;
//   width: 100%;
//   position: relative;
//   top: 0;
//   left: 0;
// `;

// export const InfoWrapper = styled.div`
//   display: flex;
//   width: 800px;
//   margin-left: auto;
//   margin-right: auto;
//   padding-top: 200px;

//   /* padding-left: 400px;
//   padding-right: 400px; */
// `;
